import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { OutingsComponent } from './outings/outings.component';
import { BoatComponent } from './boat/boat.component';
import { GalleryComponent } from './gallery/gallery.component';
import { ContactComponent } from './contact/contact.component';
import { CrewComponent } from './crew/crew.component';
import { FullDayComponent } from './tours/full-day/full-day.component';
import { SunsetCruiseComponent } from './tours/sunset-cruise/sunset-cruise.component';
import { EvjfEvgComponent } from './tours/evjf-evg/evjf-evg.component';
import { BusinessOutingComponent } from './tours/business-outing/business-outing.component';
import { TermsComponent } from './terms/terms.component';
import { SafetyInstructionsComponent } from './safety-instructions/safety-instructions.component';
import { DepositComponent } from './deposit/deposit.component';
import { ChecklistComponent } from './checklist/checklist.component';
import { AccountSummaryComponent } from './account-summary/account-summary.component';
import { MyProfileComponent } from './my-profile/my-profile.component';
import { MyFeedbacksComponent } from './my-feedbacks/my-feedbacks.component';
import { AdminFeedbacksComponent } from './admin-feedbacks/admin-feedbacks.component';
import { AdminOutingsComponent } from './admin-outings/admin-outings.component';
import { AdminOutingDetailComponent } from './admin-outing-detail/admin-outing-detail.component';
import { AdminManageOutingsComponent } from './admin-manage-outings/admin-manage-outings.component';
import { GuestFaqComponent } from './guest-faq/guest-faq.component';
import { GuestJourneyComponent } from './guest-journey/guest-journey.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'sorties', component: OutingsComponent },
  { path: 'sorties/journee-en-mer', component: FullDayComponent },
  { path: 'sorties/coucher-de-soleil', component: SunsetCruiseComponent },
  { path: 'sorties/party', component: EvjfEvgComponent },
  { path: 'sorties/anniversaire', redirectTo: 'sorties/party', pathMatch: 'full' },
  { path: 'sorties/sortie-entreprise', component: BusinessOutingComponent },
  { path: 'bateau', component: BoatComponent },
  { path: 'galerie', component: GalleryComponent },
  { path: 'contact', component: ContactComponent },
  { path: 'crew', component: CrewComponent },
  { path: 'terms', component: TermsComponent },
  { path: 'safety', component: SafetyInstructionsComponent },
  { path: 'checklist', component: ChecklistComponent },
  { path: 'deposit', component: DepositComponent },
  { path: 'faq', component: GuestFaqComponent },
  { path: 'how-it-works', component: GuestJourneyComponent },
  { path: 'my-bookings', component: AccountSummaryComponent, data: { section: 'bookings' } },
  { path: 'my-payments', component: AccountSummaryComponent, data: { section: 'payments' } },
  { path: 'my-profile', component: MyProfileComponent },
  { path: 'my-feedbacks', component: MyFeedbacksComponent },
  { path: 'leave-feedback', redirectTo: 'my-feedbacks', pathMatch: 'full' },
  { path: 'admin/feedbacks', component: AdminFeedbacksComponent },
  { path: 'admin/outings', component: AdminOutingsComponent },
  { path: 'admin/outings/:outingId', component: AdminOutingDetailComponent },
  { path: 'admin/manage-outings', component: AdminManageOutingsComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class HomeRoutingModule {}

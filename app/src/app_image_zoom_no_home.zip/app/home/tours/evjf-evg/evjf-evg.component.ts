
import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { LanguageService } from '../../../services/language.service';
import { TourPage, getTourContent } from '../tour-content';

@Component({
  selector: 'app-evjf-evg',
  templateUrl: './evjf-evg.component.html',
  styleUrls: ['./evjf-evg.component.scss'],
})
export class EvjfEvgComponent implements OnInit, OnDestroy {
  tour: TourPage = getTourContent('fr', 'anniversaire');
  private languageSub?: Subscription;

  constructor(private languageService: LanguageService) {}

  ngOnInit(): void {
    this.languageSub = this.languageService.language$.subscribe((language) => {
      this.tour = getTourContent(language, 'anniversaire');
    });
  }

  ngOnDestroy(): void {
    this.languageSub?.unsubscribe();
  }
}


import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { LanguageService } from '../../../services/language.service';
import { SITE_CONTENT } from '../../site-content';
import { TourPage, getTourContent } from '../tour-content';

@Component({
  selector: 'app-sunset-cruise',
  templateUrl: './sunset-cruise.component.html',
  styleUrls: ['./sunset-cruise.component.scss'],
})
export class SunsetCruiseComponent implements OnInit, OnDestroy {
  tour: TourPage = getTourContent('fr', 'coucher-de-soleil');
  private languageSub?: Subscription;

  constructor(private languageService: LanguageService) {}

  ngOnInit(): void {
    this.languageSub = this.languageService.language$.subscribe((language) => {
      this.tour = getTourContent(language, 'coucher-de-soleil');
    });
  }

  ngOnDestroy(): void {
    this.languageSub?.unsubscribe();
  }
}

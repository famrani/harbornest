/***************************************************************************************************
 * Load `$localize` - i18n support for Angular.
 */
import '@angular/localize/init';

/***************************************************************************************************
 * Zone JS is required by Angular itself.
 */
import 'zone.js';  // Included with Angular CLI.

/***************************************************************************************************
 * Other polyfills can be added here as needed.
 */

// (optionnel) Si tu as besoin de compatibilité IE ou d’autres anciens navigateurs, tu pourrais
// importer ici d’autres polyfills comme :
// import 'core-js/es/array';
// import 'core-js/es/object';

/***************************************************************************************************
 * APPLICATION IMPORTS
 */

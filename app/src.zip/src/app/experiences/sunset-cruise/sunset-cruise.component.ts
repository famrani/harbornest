import { Component, OnInit, ViewChild, ElementRef, OnDestroy, AfterViewChecked } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { UtilsService } from 'godigital-lib';
import { ServicesService, AUTHSTATUS } from 'godigital-lib';
import { Router, NavigationEnd } from '@angular/router';
import { ExperiencesService } from '../experiences.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

declare let $: any;

interface ChatMessage {
  role: string;
  content: string;
}

@Component({
  selector: 'app-sunset-cruise',
  templateUrl: './sunset-cruise.component.html',
  styleUrls: ['./sunset-cruise.component.css'],
  imports: [FormsModule]
})
export class SunsetcruiseComponent implements OnInit, OnDestroy, AfterViewChecked {
  @ViewChild('textInput') textInputInput: any;
  @ViewChild('chatWindow', { static: false }) chatWindowRef: ElementRef;
  public componentName = 'sunset-cruise.component';
  public loginForm: FormGroup;

  isCollapsed: boolean = true;

  constructor(
    public experiencesSvc: ExperiencesService,
    public fb: FormBuilder,
    public mainSvc: ServicesService,
    public utilsSvc: UtilsService,
    public router: Router,
  ) { }

  ngOnInit() {
    this.createForm();
  }

  ngOnDestroy() {
  }

  ngAfterViewChecked() {
  }

  goHome() {
    this.router.navigate(['/home']);
  }

  login() {
    this.experiencesSvc.localUtilsSvc.processLogin(this.loginForm.value.email, this.loginForm.value.password, undefined).then(
      data => {
        console.log('data=', data);
        const value2 = this.utilsSvc.getUid();
        this.router.navigate(['/home']);
      },
      error=> {
        console.log('login error=', error);
        if (error && error[0]===AUTHSTATUS.UNKNOWNERROR) {
          $('#loginErrorModal').modal('show');
        }
        if (error && error[0]===AUTHSTATUS.EMAILNOTVERIFIED) {
          $('#emailNotVerifiedModal').modal('show');
        }
      }
    )
  }

  createForm() {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(15)]],
      rememberme: false,
    });
  }


}

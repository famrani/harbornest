// login.component.ts
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UsersService, AUTHSTATUS, ServicesService } from 'godigital-lib'; // adjust path
import { LoginService } from '../login.service'; // adjust path

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
})
export class LoginComponent {
  loading = false;
  error = '';
  loginForm: FormGroup

  constructor(
    private fb: FormBuilder,
    private usersSvc: UsersService,
    private router: Router,
    private loginSvc: LoginService,
    private mainSvc: ServicesService,
  ) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required]],
      rememberme: [false, [Validators.required]],
    });
  }

  async loginWithEmail() {
    this.error = '';
    if (this.loginForm.invalid) {
      this.loginForm.markAllAsTouched();
      return;
    }
    const { email, password } = this.loginForm.value as { email: string; password: string };

    try {
      this.loading = true;


      const [status, user] = await this.loginSvc.localUtilsSvc.processLogin(email, password, undefined) as any;
      this.loginSvc.wnGuest = user;
      this.mainSvc.setLoggedUser(user);
      console.log('this.loginSvc.wnGuest=', this.loginSvc.wnGuest);
      if (status === AUTHSTATUS.SUCCESS) {
        // status === AUTHSTATUS.SUCCESS already handled in your service
        await this.router.navigate(['/home']); // or where you want
      }
    } catch (e: any) {
      this.error = e?.[1]?.message || e?.message || 'Login failed';
    } finally {
      this.loading = false;
    }
  }

  async loginWithGoogle() {
    this.error = '';
    try {
      this.loading = true;
      this.loginSvc.wnGuest = await this.usersSvc.signInWithGoogleAndLoadProfile();   // ✅ reuses your existing method
      this.mainSvc.setLoggedUser(this.loginSvc.wnGuest);
      await this.router.navigate(['/tours']); // go to dashboard
    } catch (e: any) {
      // Common: popup blocked or disallowed_useragent in embedded webviews
      if (e?.code === 'auth/popup-blocked') {
        this.error = 'Popup was blocked. Please allow popups or try again.';
      } else if (e?.code === 'auth/account-exists-with-different-credential') {
        this.error = 'This email is already used with another sign-in method.';
      } else {
        this.error = e?.message || 'Google sign-in failed.';
      }
    } finally {
      this.loading = false;
    }
  }
}

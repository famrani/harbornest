export const environment = {
  production: true,
  payment: {
    stripe: {
      publishableKey: "pk_live_yzbFt5Ov10mQB3YnWIpeW2N5"
    }
  }
};

export const environment = {
  production: false,
  payment:{
    stripe:{
      publishableKey:"pk_test_ksDl8VQ7yCT2HDpDGN0hBUXe"
    }
  }
};